#include "game_event.h"

namespace ijengine
{
    namespace game_event
    {
        const unsigned QUIT = GameEvent::assign_id();
        const unsigned PAUSE = GameEvent::assign_id();
    }
}

