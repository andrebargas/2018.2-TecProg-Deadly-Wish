#include "color.h"

namespace ijengine
{
    const Color Color::WHITE(255, 255, 255);
    const Color Color::BLACK(0, 0, 0);
}
